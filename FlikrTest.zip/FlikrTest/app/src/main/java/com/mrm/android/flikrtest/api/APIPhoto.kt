package com.mrm.android.flikrtest.api

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class APIPhoto(val title: String, val media: String,
                    val dateTaken: String, val author: String, val tags: List<String>):Parcelable