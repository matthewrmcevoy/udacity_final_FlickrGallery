package com.mrm.android.flikrtest.api

import org.json.JSONObject

fun parseAPIPhotosJsonResult(jsonResult: JSONObject): ArrayList<APIPhoto>{
   // val flikrFeedJson = jsonResult.getJSONObject("items")
    val test = jsonResult.getJSONArray("items")

    val photoList = ArrayList<APIPhoto>()
   // val photoJsonArray = flikrFeedJson.getJSONArray("items")

    var tagsList: List<String> = listOf()

    for(i in 0 until test.length()) {
        val photoJson = test.getJSONObject(i)
        val title = photoJson.getString("title")
        val media = photoJson.getJSONObject("media")
            .getString("m")
        val dateTaken = photoJson.getString("date_taken")
        val authorFlikr = photoJson.getString("author")
        val tagsString = photoJson.getString("tags")
        //Convert string of tags to a list of string tags
        tagsList = tagsString.trim().splitToSequence(' ').filter{it.isNotEmpty()}.toList()

        val apiPhoto = APIPhoto(title, media,dateTaken,authorFlikr, tagsList)
        photoList.add(apiPhoto)
    }


    return photoList
}

