package com.mrm.android.flikrtest.ui.detail

class DetailViewModel {
}