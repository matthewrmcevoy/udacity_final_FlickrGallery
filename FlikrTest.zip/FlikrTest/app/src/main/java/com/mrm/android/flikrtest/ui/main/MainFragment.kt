package com.mrm.android.flikrtest.ui.main

import android.content.Context
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import androidx.core.content.ContextCompat.getSystemService
import androidx.navigation.fragment.findNavController
import com.mrm.android.flikrtest.R
import com.mrm.android.flikrtest.databinding.FragmentMainBinding
import kotlinx.android.synthetic.main.fragment_main.*

class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)



    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentMainBinding.inflate(inflater)
        binding.photosGrid.adapter = PhotoGridAdapter(PhotoGridAdapter.OnClickListener{

        })

        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel

        var searchText:String = ""
        val recentSearch:MutableList<String> = mutableListOf()
        val actv:AutoCompleteTextView = binding.root.findViewById(R.id.tag_search_txt)

        actv.setOnClickListener{
            actv.showDropDown()
        }

        binding.imageButton.setOnClickListener {
            searchText = tag_search_txt.text.toString()
            if(recentSearch.contains(searchText) || searchText =="" ){
                null
            }else{
                if(recentSearch.size <= 4 ){
                    recentSearch.add(0,searchText)
                }else{
                    recentSearch.add(0, searchText)
                    recentSearch.removeAt(5)
                }
            }
            Log.i("Fragment","recent searches are ${recentSearch}")
            viewModel.updatePhotoFilter(searchText)
            val adapter = ArrayAdapter<String>(requireActivity(),R.layout.search_history, recentSearch)
            actv.setAdapter(adapter)


            val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(requireView().windowToken, 0)

            tag_search_txt.setText("")
            tag_search_txt.clearFocus()
        }

        return binding.root
    }

}