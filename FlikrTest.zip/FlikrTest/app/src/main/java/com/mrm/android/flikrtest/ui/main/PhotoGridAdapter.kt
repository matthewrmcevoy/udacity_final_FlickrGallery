package com.mrm.android.flikrtest.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mrm.android.flikrtest.api.APIPhoto
import com.mrm.android.flikrtest.databinding.GridViewItemBinding

class PhotoGridAdapter(private val onClickListener: OnClickListener) : ListAdapter<APIPhoto, PhotoGridAdapter.APIPhotoViewHolder>(DiffCallback) {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PhotoGridAdapter.APIPhotoViewHolder {
        return APIPhotoViewHolder(GridViewItemBinding.inflate(LayoutInflater.from(parent.context)))
    }

    override fun onBindViewHolder(holder: PhotoGridAdapter.APIPhotoViewHolder, position: Int) {
        val apiPhoto = getItem(position)
        holder.bind(apiPhoto)
        holder.itemView.setOnClickListener{
            onClickListener.onClick(apiPhoto)
        }
    }

    class APIPhotoViewHolder(private var binding: GridViewItemBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(apiPhoto: APIPhoto?){
            binding.photo = apiPhoto
            binding.executePendingBindings()
        }
    }
    companion object DiffCallback : DiffUtil.ItemCallback<APIPhoto>() {
        override fun areItemsTheSame(oldItem: APIPhoto, newItem: APIPhoto): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: APIPhoto, newItem: APIPhoto): Boolean {
            return oldItem.media == newItem.media
        }
    }
    class OnClickListener(val clickListener: (marsProperty: APIPhoto) -> Unit){
        fun onClick(marsProperty: APIPhoto) = clickListener(marsProperty)
    }
}


